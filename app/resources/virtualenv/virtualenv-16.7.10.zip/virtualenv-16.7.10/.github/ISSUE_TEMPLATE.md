Thanks for submitting an issue!

If submitting a BUG please provide:

- [ ] Minimal reproducible example or detailed descriptions
- [ ] OS and `pip list` output


if submitting an ENHANCEMENT issue:

- [ ] a clear problem statement with an example
- [ ] suggested change with example
- [ ] if you have want help to do a PR yourself
